//////////////////////////////////////////////////////
// OpenGL files for Robotics applications
// 
// Copyright (c) 2002-2010. All Rights Reserved.
// Division of Applied Robot Technology, KITECH
// Web: http://www.orobot.net
// Written by KwangWoong Yang<page365@gmail.com>
//

#pragma once
#include "OglWnd.h"
#include "Kinematics.h"

class COglWndCustom : public COglWnd
{
public:
	COglWndCustom (CKinematics *kin);

	virtual void OnDraw(CDC* pDC);

	bool _showAxis;

private:
	CKinematics *_kin;

	void TransformAxis(dMatrix &A);
	void DrawRevLink (double x, double y, double z, double radius);

	void DrawFixedJoint (JointInfo *joint);
	void DrawRevoluteJoint (JointInfo *joint);
	void DrawPrismaticJoint (JointInfo *joint);

	void RenderTarget ();
	void RenderJoint();
};
