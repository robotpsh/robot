//////////////////////////////////////////////////////
// Kinematics files for Robotics applications
// 
// Copyright (c) 2002-2010. All Rights Reserved.
// Division of Applied Robot Technology, KITECH
// Web: http://www.orobot.net
// Written by KwangWoong Yang<page365@gmail.com>
//

#pragma	once

#include "Kinematics.h"


class CPosInverse : public CKinematics
{
public:
	CPosInverse (); 
	~CPosInverse (); 
	
	void SetDesired (double x, double y, double z);	// �������� ��ġ�� �����Ѵ�.

	virtual dMatrix Forward ();
	virtual dVector Error ();
	virtual dMatrix Jacobian ();
};
