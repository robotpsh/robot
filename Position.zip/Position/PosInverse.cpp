//////////////////////////////////////////////////////
// Kinematics files for Robotics applications
// 
// Copyright (c) 2002-2010. All Rights Reserved.
// Division of Applied Robot Technology, KITECH
// Web: http://www.orobot.net
// Written by KwangWoong Yang<page365@gmail.com>
//

#include "StdAfx.h"
#include "PosInverse.h"
#include "Transformation.h"


CPosInverse::CPosInverse ()
: CKinematics(3)
{ 
}

CPosInverse::~CPosInverse ()
{
}

dMatrix CPosInverse::Forward ()
{
	CTransformMatrix T;

	for (unsigned int i=0; i<_jointList.size (); ++i) {
		JointInfo *joint = _jointList[i];

		dMatrix A = joint->TransformationMatrix ();

		joint->a = T.GetRotation (joint->axis);		// ȸ�� ���� ȸ�� ���� (���ӵ�)
		joint->p = T.GetPosition ();				// ���� ��ǥ�迡���� ���� ��ġ

		T *= A;
	}
	_current = T.GetPosition ();

	return T;
}

dMatrix CPosInverse::Jacobian()
{
	//Position Jacobian 
	dMatrix J(3, _jointList.size());

	dVector currentPos (3);
	currentPos[0] = _current[0];
	currentPos[1] = _current[1]; 
	currentPos[2] = _current[2]; 

	for (unsigned int i=0; i<_jointList.size (); ++i) {
		JointInfo *joint = _jointList[i];

		if (joint->type == REVOLUTE_JOINT) {
			dVector pos = Cross (joint->a, currentPos - joint->p);
			J(0,i) = pos[0];
			J(1,i) = pos[1];
			J(2,i) = pos[2];
		}
		else if (joint->type == PRISMATIC_JOINT) {
			J(0,i) = joint->a[0];
			J(1,i) = joint->a[1];
			J(2,i) = joint->a[2];
		}
		else {
			J(0,i) = 0.;
			J(1,i) = 0.;
			J(2,i) = 0.;
		}
	}
	return J;
}

dVector CPosInverse::Error ()
{
	return _desired - _current;
}

void CPosInverse::SetDesired (double x, double y, double z)
{
	_desired[0] = x;		
	_desired[1] = y;		
	_desired[2] = z; 
}

